import express from 'express';
import User from '../model/User.js';
import verify from '../middlewares/verifyToken.js';
import fs from 'fs';
import { uuid } from 'uuidv4';
import path from 'path';
import multer from 'multer';
import AdmZip from 'adm-zip'; // For extracting DOCX files
import libxmljs from 'libxmljs';
const router = express.Router();

router.get('/', verify, async (req, res) => {
    const userobj = await User.findById(req.user._id);
    const documentIds = userobj.uploadedDocx.map((docx) => docx.filename);
    res.render('view-docx', { documentIds });
  });


router.get('/:id', verify, async (req, res) => {
    const docxId = req.params.id;

    try {
        // Fetch the user object
        const user = await User.findById(req.user._id);

        // Find the document with the specified ID in the user's uploadedDocx array
        const document = user.uploadedDocx.find((doc) => doc.filename === docxId);

        if (!document) {
            return res.status(404).json({ error: 'Document not found' });
        }

        // Extract the content of document.xml from the DOCX file
        const docxFilePath = document.filePath;
        const docxZip = new AdmZip(docxFilePath);
        const docxEntries = docxZip.getEntries();

        const documentXmlEntry = docxEntries.find((entry) =>
            entry.entryName === 'word/document.xml'
        );

        if (!documentXmlEntry) {
            return res.status(500).json({ error: 'document.xml not found in DOCX file' });
        }

        const documentXmlContent = docxZip.readAsText(documentXmlEntry);

        // Parse the XML content to extract the text
        const xmlDoc = libxmljs.parseXml(documentXmlContent,{noent:true,noblanks:true});
        // xmlDoc.defineNamespace('w', namespaces.w);
        const textContent = extractTextContent(xmlDoc);
        
        // console.log(textContent);
        res.render('view-docx-id', { content: textContent });
        // parser.parseXml(documentXmlContent, (err, result) => {
        //     if (err) {
        //         return res.status(500).json({ error: 'Error parsing document.xml' });
        //     }
        //     // console.log(result['w:document']['w:body'][0]['w:p']);
        //     // Extract and send the text content
        //     const textContent = extractTextContent(result);


        //     res.render('view-docx-id', { content: textContent });
        // });
    } catch (error) {
        console.error('Error fetching and parsing DOCX file:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

function extractTextContent(xmlDoc) {
    // Initialize an array to store text content
    const textContent = [];

    // Find all <w:t> elements within the XML document
    const textElements = xmlDoc.find('//*[local-name()="t"]');

    // Iterate through the text elements and extract text
    textElements.forEach((textElement) => {
        const text = textElement.text();
        textContent.push(text);
    });

    return textContent;
}



export default router;