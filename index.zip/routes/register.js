import express from 'express';
import User from '../model/User.js';
import bcrypt from 'bcryptjs'

const router = express.Router();

router.get('/', (req, res) => {
    res.render('register');
  });

router.post('/', async (req, res) => {
    const { body } = req;
    const {
        username,
        password
    } = body;
    
    // username = username.toLowerCase();
    const response = await User.find({
        username: username
    })
    console.log(response);
    //Hash passwords
    if ( response.length > 0)
    {   

       return res.status(201).json({msg : "Account already exists!"});
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const newuser = new User({
        username: username,
        password: hashedPassword,
    });
    try {
        const savedUser = await newuser.save();
        // #return res.send({user: savedUser._id});
        res.redirect('/login');


    }catch(err) {
        return res.status(201).send(err);
    }
});

export default router;