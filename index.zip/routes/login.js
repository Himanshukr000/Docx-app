import express from 'express';
import User from '../model/User.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();


router.get('/', (req, res) => {
    res.render('login');
  });

router.post('/', async (req, res) => {
    const { body } = req;
    const {
        username,
        password
    } = body;

    const user = await User.findOne({ username: username });
    if (!user) {
        return res.status(400).json({ msg: 'Invalid credentials' });
    }
    const validPass = await bcrypt.compare(password, user.password);
    if (!validPass)
    {
        return res.status(400).json({ msg: 'Invalid credentials' });
    }

    //Create and assign JWT
    const token = jwt.sign({ _id: user._id, username: user.username, uploadedDocx: user.uploadedDocx}, 'lol123lol');
    res.cookie('auth',token);
    res.header('Auth-token', token).json({ token });
    res.redirect('/upload');
    
});

export default router;