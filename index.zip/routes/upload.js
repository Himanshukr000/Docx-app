import express from 'express';
import User from '../model/User.js';
import verify from '../middlewares/verifyToken.js';
import fs from 'fs';
import { uuid } from 'uuidv4';
import path from 'path';
import multer from 'multer';
const router = express.Router();

const upload = multer({ dest: 'uploads/' })

router.get('/', verify, (req, res) => {
    res.render('upload-docx');
  });
router.post('/', verify, upload.single('docxFile'), async (req, res, next) => {
    if (!req.file) {
      return res.status(400).send('No DOCX content provided.');
    }
  
    //console.log(req.file);
    // Define the file path where the DOCX file will be saved
    const filePath = path.join(process.cwd(), 'uploads', req.file.filename);
  
      // Store the file information in MongoDB
      const newDocx = {
        filename: req.file.filename,
        filePath: filePath,
      };
      console.log(req.user);
      const userobj = await User.findById(req.user._id);
      userobj.uploadedDocx.push(newDocx);
      userobj.save();
    //   req.user.uploadedDocx.push(newDocx);
    //   req.user.save();
        res.redirect('/view');
      });


export default router;