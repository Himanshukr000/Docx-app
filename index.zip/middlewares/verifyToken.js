import jwt from 'jsonwebtoken';
import User from '../model/User.js';

async function verify  (req, res, next) {
    const token = req.header('auth-token') || req.cookies.auth;
    if (!token) return res.status(401).send('Access Denied!');

    try {
        const verified = jwt.verify(token, 'lol123lol');
        req.user = verified;
        const userob = await User.findById(req.user._id);
        // req.user.team = userob.teams[0];
        // console.log('USEROB TEAM', userob.teams);
        // console.log('REQ OBJCECT',req.user.team);
        next();

    }catch(err) {
        res.status(400).send('Invalid Token!');
    }
}

export default verify;