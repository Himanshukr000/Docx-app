import mongoose from 'mongoose';

const Schema = mongoose.Schema;
const UserSchema = new Schema(
    {
        username: {
            type: String,
            required: true,
            unique: true,
            index: true,
        },
        password: {
            type: String,
            required: true
        },
        uploadedDocx: [
            {
              filename: String, // Store the file's original name
              filePath: String, // Store the path to the uploaded file on the server
            },
          ]

    }
);

const User = mongoose.model('User', UserSchema);
export default User;

//Create a subschema instead of isJoined & teams.
// type: array of Objects