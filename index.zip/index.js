import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';
import indexRoute from './routes/indexRoute.js';
import registerRoute from './routes/register.js';
import loginRoute from './routes/login.js';
import uploadRoute from './routes/upload.js';
import viewDocxRoute from './routes/view-docx.js';
import cookieParser from 'cookie-parser';
import multer from 'multer';
import AdmZip from 'adm-zip'; // For extracting DOCX files
import libxmljs from 'libxmljs';

const app = express();

//Middleware
app.use(cors(), function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "http://localhost:5000");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept"
    );
    next();
  });
app.set('view engine', 'ejs');

app.use(express.json());
app.use(cookieParser());
app.set('/views', express.static(process.cwd() + '/views'));



const PORT = process.env.PORT || 5000;
app.use('/', indexRoute);
app.use('/register', registerRoute);
app.use('/login', loginRoute);
app.use('/upload', uploadRoute);
app.use('/view', viewDocxRoute);
mongoose.connect('mongodb://localhost:27017/docx-app',
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  }
);

app.listen(PORT, () => console.log(`Server running on port: ${PORT}`));
